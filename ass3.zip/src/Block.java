import java.awt.Color;

/**
 * @author Hadar Sabag <hadarsbg@gmail.com>
 * @version 1.8
 * @since 2017-05-09
 */
public class Block implements Collidable, Sprite {
    private Rectangle blockRect;
    private int hitPoints = 0;
    private Color color = Color.gray;

    /**
     * class constructor.
     *
     * @param rect      - the block shape - a rectangle
     * @param hitPoints - number of hits allowed for the block
     */
    public Block(Rectangle rect, int hitPoints) {
        this.blockRect = rect;
        this.hitPoints = hitPoints;
    }

    /**
     * set the color of the ball to given color.
     *
     * @param c - color
     */
    public void setColor(Color c) {
        this.color = c;
    }

    /**
     * Return the "collision shape" of the object.
     *
     * @return this.blockRect
     */
    public Rectangle getCollisionRectangle() {
        return this.blockRect;
    }

    /**
     * set the number hit points allowed.
     *
     * @param newhitPoints - number of hit points
     */
    public void setHitPoints(int newhitPoints) {
        this.hitPoints = newhitPoints;
    }

    /**
     * return the number of hit points of the block.
     *
     * @return hitPoints -number of hit points
     */
    public int getHitPoints() {
        return this.hitPoints;
    }

    /**
     * Notify the object that we collided with it at collisionPoint with
     * // a given velocity.
     * // The return is the new velocity expected after the hit (based on
     * // the force the object inflicted on us).
     *
     * @param collisionPoint  - point of collision with rectangle
     * @param currentVelocity - balls velocity
     * @return new velocity
     */
    public Velocity hit(Point collisionPoint, Velocity currentVelocity) {
        //if hits corners
        if (collisionPoint.equals(blockRect.getLowerLeft()) || collisionPoint.equals(blockRect.getLowerRight())
                || collisionPoint.equals(blockRect.getUpperLeft())
                || collisionPoint.equals(blockRect.getUpperRight())) {
            this.setHitPoints(--this.hitPoints);
            return new Velocity((-1) * currentVelocity.getDx(), (-1) * currentVelocity.getDy());
        }
        //if hits upper or lower side
        if (collisionPoint.getY() == blockRect.getUpperLeft().getY()
                || collisionPoint.getY() == blockRect.getLowerLeft().getY()) {
            this.setHitPoints(--this.hitPoints);
            return new Velocity(currentVelocity.getDx(), (-1) * currentVelocity.getDy());
        }
        //if hits left or right side
        if (collisionPoint.getX() == blockRect.getUpperLeft().getX()
               || collisionPoint.getX() == blockRect.getUpperRight().getX()) {
            this.setHitPoints(--this.hitPoints);
            return new Velocity((-1) * currentVelocity.getDx(), currentVelocity.getDy());
        }
        //if doesn't hit block
        return currentVelocity;
    }

    /**
     * draw the block on the given DrawSurface.
     *
     * @param surface -a draw surface
     */
    public void drawOn(biuoop.DrawSurface surface) {
        String s;
        if (this.hitPoints > 0) {
            s = Integer.toString(this.getHitPoints());
        } else {
            s = "x";
        }
        surface.setColor(this.color);
        surface.fillRectangle((int) this.blockRect.getUpperLeft().getX(), (int) this.blockRect.getUpperLeft().getY(),
                (int) this.blockRect.getWidth(), (int) this.blockRect.getHeight());
        surface.setColor(Color.white);
        surface.drawRectangle((int) this.blockRect.getUpperLeft().getX(), (int) this.blockRect.getUpperLeft().getY(),
                (int) this.blockRect.getWidth(), (int) this.blockRect.getHeight());
        surface.setColor(Color.BLACK);
        surface.drawText((int) (this.blockRect.getUpperLeft().getX() + (this.blockRect.getWidth() / 2)),
                (int) (this.blockRect.getUpperLeft().getY() + (this.blockRect.getHeight() / 2)), s, 15);
    }

    /**
     * interface method- return.
     */
    public void timePassed() {
        return;
    }

    /**
     * add the block to the game as a collidable and as asprite.
     * @param game - a game object
     */
    public void addToGame(Game game) {
        game.addCollidable(this);
        game.addSprit(this);
    }
}