import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

import java.awt.Color;
import java.util.ArrayList;


/**
 * @author Hadar Sabag <hadarsbg@gmail.com>
 * @version 1.8
 * @since 2017-05-09
 */
public class Game {
    private SpriteCollection sprites = new SpriteCollection();
    private GameEnvironment environment = new GameEnvironment();
    private GUI gui = new GUI("Arkanoid", 1100, 800);

    /**
     * add a collidable object to the game.
     *
     * @param c - a collidable
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /**
     * add a sprite object to the game.
     *
     * @param s - a sprit object
     */
    public void addSprit(Sprite s) {
        this.sprites.addSprite(s);
    }

    /**
     * return game gui.
     *
     * @return this. gui - the game gui
     */
    public GUI getGui() {
        return this.gui;
    }


    /**
     * Initialize a new game: create the Blocks and Ball (and Paddle)
     * // and add them to the game.
     */
    public void initialize() {

        Paddle paddle = new Paddle(new Rectangle(new Point(50, 730), 150, 40), this,
                1070, 30);
        Ball ball1 = new Ball(40, 40, 6, java.awt.Color.BLACK, this.environment);
        ball1.setVelocity(Velocity.fromAngleAndSpeed(135, 6));
        ball1.addToGame(this);
        Ball ball2 = new Ball(400, 400, 6, java.awt.Color.BLACK, this.environment);
        ball2.setVelocity(Velocity.fromAngleAndSpeed(10, 6));
        ball2.addToGame(this);
        //set the blocks of the borders
        Block up = new Block(new Rectangle(new Point(0, 0), 1100, 30), 0);
        Block down = new Block(new Rectangle(new Point(0, 770), 1100, 30), 0);
        Block left = new Block(new Rectangle(new Point(0, 0), 30, 770), 0);
        Block right = new Block(new Rectangle(new Point(1070, 0), 30, 800), 0);
        up.addToGame(this);
        down.addToGame(this);
        left.addToGame(this);
        right.addToGame(this);
        paddle.addToGame(this);
        //set the small blocks in the middle
        int blockWidth = 60;
        int blockHight = 35;
        java.util.List<Color> colors = new ArrayList<>();
        colors.add(Color.cyan);
        colors.add(Color.blue);
        colors.add(Color.green);
        colors.add(Color.orange);
        colors.add(Color.pink);
        colors.add(Color.MAGENTA);
        int hits = 2;
        int row = 13;
        for (int j = 1; j <= 6; j++) {
            Color c = colors.get(j - 1);
            for (int i = 1; i < row; i++) {
                if (row != 13) {
                    hits = 1;
                }
                Block block = new Block(new Rectangle(new Point(1070 - (i * blockWidth), 150 + (j * blockHight)),
                        blockWidth, blockHight), hits);
                block.setColor(c);
                block.addToGame(this);
            }
            row--;
        }
    }

    /**
     * Run the game -- start the animation loop.
     */
    public void run() {
        Sleeper sleeper = new Sleeper();
        // GUI gui = this.gui;
        int framesPerSecond = 60;
        int millisecondsPerFrame = 1000 / framesPerSecond;
        while (true) {
            long startTime = System.currentTimeMillis(); // timing
            DrawSurface d = this.getGui().getDrawSurface();
            this.sprites.drawAllOn(d);
            gui.show(d);
            this.sprites.notifyAllTimePassed();

            // timing
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }

}
